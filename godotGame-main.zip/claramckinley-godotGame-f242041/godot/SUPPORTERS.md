This is a list of people who decided to support my plugin with donations. Even though they are not explicitly requested, they would help me pay a part of my university fees and also encourage me to keep my projects updated and make new ones.  
*A huge thank you to:*    
- Russel aka [masterworm2](https://github.com/masterworm2)  
- Autcru aka [autcru](https://github.com/autcru)
- Itch.io users (can't publish their name until their agreement)
  
  

  
  
  
  
  
  
  
    
  
  

  
  
  

  
  

  
  
    
  
  
  
-----------------
> This text file was created via [TextEditor Integration](https://github.com/fenix-hub/godot-engine.text-editor) inside Godot Engine's Editor.


